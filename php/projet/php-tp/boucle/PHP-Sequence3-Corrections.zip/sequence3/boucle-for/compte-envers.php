<?php

for($nombre = 50; $nombre >= 0; $nombre-=3) {
    echo $nombre . ' ';
}